
import React from 'react';

const OrangeDataMinerSection: React.FC = () => {
  return (
    <section className="bg-slate-light p-8 md:p-12 rounded-2xl border border-slate-700 animate-fade-in" style={{ animationDelay: '800ms' }}>
      <div className="text-center">
        <img src="https://picsum.photos/seed/orangeui/100/100" alt="Orange Logo" className="w-20 h-20 mx-auto rounded-full mb-4 border-4 border-orange-primary"/>
        <h2 className="text-3xl font-bold text-center mb-4">¿Y Dónde Entra <span className="text-orange-primary">Orange</span> en Todo Esto?</h2>
        <p className="text-center text-gray-400 max-w-3xl mx-auto mb-12">
          ¡Orange Data Mining es la herramienta que te permite construir estas redes neuronales sin escribir ni una línea de código! Es como jugar con bloques de construcción digitales.
        </p>
      </div>

      <div className="flex flex-col md:flex-row items-center gap-8">
        <div className="flex-1 space-y-4">
          <div className="flex items-start gap-4">
            <div className="mt-1 flex-shrink-0 w-6 h-6 rounded-full bg-orange-primary/20 text-orange-primary flex items-center justify-center font-bold">1</div>
            <p><span className="font-bold text-white">Arrastra y Suelta:</span> Conectas "widgets" (bloques) para crear un flujo de trabajo. Un widget para cargar datos, otro para la red neuronal, y otro para ver los resultados.</p>
          </div>
          <div className="flex items-start gap-4">
            <div className="mt-1 flex-shrink-0 w-6 h-6 rounded-full bg-orange-primary/20 text-orange-primary flex items-center justify-center font-bold">2</div>
            <p><span className="font-bold text-white">Visual e Intuitivo:</span> Ves tus datos y el comportamiento de tu modelo en tiempo real. Es perfecto para experimentar y aprender.</p>
          </div>
          <div className="flex items-start gap-4">
            <div className="mt-1 flex-shrink-0 w-6 h-6 rounded-full bg-orange-primary/20 text-orange-primary flex items-center justify-center font-bold">3</div>
            <p><span className="font-bold text-white">Poderoso y Gratuito:</span> Aunque es fácil de usar, es una herramienta muy potente utilizada por estudiantes, profesores e investigadores de todo el mundo. ¡Y es de código abierto!</p>
          </div>
        </div>
        <div className="flex-1 mt-8 md:mt-0">
            {/* Simulación visual de la UI de Orange */}
            <div className="bg-slate-deep p-6 rounded-lg border-2 border-slate-700 transform md:rotate-2 md:hover:rotate-0 transition-transform duration-300">
                <p className="text-sm font-mono text-gray-500 mb-4">// Flujo de trabajo simple en Orange:</p>
                <div className="flex items-center justify-center space-x-2 md:space-x-4">
                    <div className="bg-sky-500 text-white text-xs md:text-sm font-bold p-3 rounded shadow-md text-center">Cargar<br/>Datos</div>
                    <div className="font-mono text-orange-400 text-xl font-bold">→</div>
                    <div className="bg-orange-500 text-white text-xs md:text-sm font-bold p-3 rounded shadow-md text-center">Red<br/>Neuronal</div>
                    <div className="font-mono text-orange-400 text-xl font-bold">→</div>
                    <div className="bg-emerald-500 text-white text-xs md:text-sm font-bold p-3 rounded shadow-md text-center">Ver<br/>Predicción</div>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default OrangeDataMinerSection;
