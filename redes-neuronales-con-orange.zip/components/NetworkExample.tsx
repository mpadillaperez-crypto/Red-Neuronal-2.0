
import React, { useState, useEffect } from 'react';

const Neuron: React.FC<{ active: boolean; label?: string; isOutput?: boolean }> = ({ active, label, isOutput }) => (
  <div className="flex flex-col items-center">
    <div className={`w-12 h-12 md:w-16 md:h-16 rounded-full border-2 flex items-center justify-center transition-all duration-500
      ${active ? 'bg-orange-500 border-orange-300 shadow-lg shadow-orange-500/50' : 'bg-slate-700 border-slate-600'}
      ${isOutput ? 'w-16 h-16 md:w-20 md:h-20' : ''}`}>
        {label && <span className="text-xs font-bold text-white">{label}</span>}
    </div>
  </div>
);

const Connection: React.FC<{ active: boolean; delay: string }> = ({ active, delay }) => (
    <div className="absolute top-1/2 left-0 w-full h-0.5 transition-all duration-700" style={{ transitionDelay: delay }}>
        <div className={`h-full transition-all duration-500 ${active ? 'bg-orange-400' : 'bg-slate-700'}`} style={{ width: active ? '100%' : '0%' }}></div>
    </div>
);


const NetworkExample: React.FC = () => {
  const [color, setColor] = useState(5); // 0 (rojo) to 10 (naranja)
  const [shape, setShape] = useState(8); // 0 (redondo) to 10 (más redondo)

  const [h1Active, setH1Active] = useState(false);
  const [h2Active, setH2Active] = useState(false);
  const [outputIsOrange, setOutputIsOrange] = useState(false);

  useEffect(() => {
    // Simulación simplificada de una red
    const colorWeightH1 = 0.6;
    const shapeWeightH1 = 0.4;
    const activationH1 = (color / 10 * colorWeightH1) + (shape / 10 * shapeWeightH1);
    
    const colorWeightH2 = -0.3; // A esta neurona no le "gusta" el color naranja
    const shapeWeightH2 = 0.8;
    const activationH2 = (color / 10 * colorWeightH2) + (shape / 10 * shapeWeightH2);

    const h1Fired = activationH1 > 0.5;
    const h2Fired = activationH2 > 0.4;

    setH1Active(h1Fired);
    setH2Active(h2Fired);

    const h1WeightOutput = 0.7;
    const h2WeightOutput = 0.3;
    
    const outputActivation = ( (h1Fired ? 1 : 0) * h1WeightOutput) + ( (h2Fired ? 1 : 0) * h2WeightOutput);
    setOutputIsOrange(outputActivation > 0.6);

  }, [color, shape]);

  const fruitColor = `rgb(255, ${255 - color * 16}, 0)`;

  return (
    <section className="animate-fade-in" style={{ animationDelay: '600ms' }}>
      <h2 className="text-3xl font-bold text-center mb-4">De Neuronas a Redes: El Poder de la Conexión</h2>
      <p className="text-center text-gray-400 max-w-2xl mx-auto mb-12">
        Al conectar neuronas en capas, pueden resolver problemas más complejos. Juguemos a clasificar una fruta: ¿es una Manzana o una Naranja?
      </p>

      <div className="grid lg:grid-cols-3 gap-8 items-center">
        {/* Controles */}
        <div className="bg-slate-light p-8 rounded-xl border border-slate-700 self-stretch">
          <h3 className="text-xl font-bold mb-6">Características de la Fruta</h3>
          <div className="space-y-6">
            <div>
              <label className="block mb-2">Color</label>
              <div className="flex items-center gap-4">
                <span className="text-red-500 font-semibold">Manzana</span>
                <input type="range" min="0" max="10" value={color} onChange={(e) => setColor(Number(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-primary" />
                <span className="text-orange-500 font-semibold">Naranja</span>
              </div>
            </div>
            <div>
              <label className="block mb-2">Forma</label>
              <div className="flex items-center gap-4">
                <span className="font-semibold">Menos Redonda</span>
                <input type="range" min="0" max="10" value={shape} onChange={(e) => setShape(Number(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-primary" />
                <span className="font-semibold">Más Redonda</span>
              </div>
            </div>
          </div>
          <div className="mt-8 text-center">
             <div className="w-24 h-24 rounded-full mx-auto transition-colors duration-300" style={{ backgroundColor: fruitColor, boxShadow: `0 0 20px ${fruitColor}` }}></div>
          </div>
        </div>

        {/* Visualización de la Red */}
        <div className="lg:col-span-2 flex items-center justify-around h-full p-8 bg-slate-900/50 rounded-xl relative">
            {/* Conexiones */}
            <div className="absolute w-1/4 h-full top-0 left-[12.5%] z-0">
                <Connection active={h1Active} delay="0s" />
                <Connection active={h2Active} delay="100ms" />
            </div>
             <div className="absolute w-1/4 h-full top-0 right-[12.5%] z-0">
                <div className="absolute w-full h-0.5 top-[33.3%] left-0 origin-left" style={{ transform: 'rotate(18.4deg) scaleX(1.118)' }}><Connection active={h1Active && outputIsOrange} delay="200ms" /></div>
                <div className="absolute w-full h-0.5 top-[66.6%] left-0 origin-left" style={{ transform: 'rotate(-18.4deg) scaleX(1.118)' }}><Connection active={h2Active && outputIsOrange} delay="300ms" /></div>
            </div>

            {/* Capas de Neuronas */}
            <div className="flex flex-col justify-around h-full z-10">
                <Neuron active={color > 5} label="Color" />
                <Neuron active={shape > 5} label="Forma" />
            </div>
            <div className="flex flex-col justify-around h-full z-10">
                <Neuron active={h1Active} label="H1"/>
                <Neuron active={h2Active} label="H2"/>
            </div>
            <div className="z-10 text-center">
                <Neuron active={outputIsOrange} isOutput={true} />
                <p className={`mt-4 text-2xl font-bold transition-colors ${outputIsOrange ? 'text-orange-400' : 'text-red-400'}`}>
                    {outputIsOrange ? '¡Es una Naranja!' : '¡Es una Manzana!'}
                </p>
            </div>
        </div>
      </div>
    </section>
  );
};

export default NetworkExample;
