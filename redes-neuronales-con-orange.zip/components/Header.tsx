
import React from 'react';
import { BrainIcon } from './Icons';

const Header: React.FC = () => {
  return (
    <header className="text-center mb-16 md:mb-24 animate-fade-in">
      <div className="inline-block bg-orange-primary/10 p-4 rounded-full mb-4">
        <BrainIcon className="h-12 w-12 text-orange-primary" />
      </div>
      <h1 className="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-orange-secondary to-orange-primary">
        Descubriendo las Redes Neuronales
      </h1>
      <p className="mt-4 text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">
        Una aventura interactiva para entender cómo "piensan" las máquinas, con la ayuda de <span className="font-bold text-orange-secondary">Orange</span>.
      </p>
    </header>
  );
};

export default Header;
