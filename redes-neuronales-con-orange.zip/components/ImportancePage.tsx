import React from 'react';
import { ArrowLeftIcon, SmartphoneIcon, CameraIcon, TranslateIcon, ShieldIcon, ThumbsUpIcon, CarIcon } from './Icons';
import CartesianClassifier from './CartesianClassifier';

const Card: React.FC<{ title: string; children: React.ReactNode; icon: React.ReactNode }> = ({ title, children, icon }) => (
    <div className="bg-slate-light p-6 rounded-xl border border-slate-700 hover:border-orange-primary transition-all duration-300 transform hover:-translate-y-1 h-full">
      <div className="flex items-center gap-4 mb-3">
        <div className="bg-orange-primary/10 text-orange-primary p-3 rounded-lg">{icon}</div>
        <h3 className="text-xl font-bold text-white">{title}</h3>
      </div>
      <p className="text-gray-400">{children}</p>
    </div>
  );
  

const ImportancePage: React.FC<{ onNavigate: () => void }> = ({ onNavigate }) => {
    return (
        <section className="animate-fade-in">
            <header className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-orange-secondary to-orange-primary">
                    ¿Por Qué Son Tan Importantes?
                </h1>
                <p className="mt-4 text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">
                    Las redes neuronales son el motor silencioso detrás de la tecnología que usas todos los días. ¡Están por todas partes!
                </p>
            </header>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <Card title="Tu 'Feed' Personalizado" icon={<ThumbsUpIcon className="h-8 w-8" />}>
                    ¿Te preguntas cómo Netflix sabe qué película te gustará o por qué TikTok te conoce tan bien? Las redes neuronales analizan tus gustos para crear una experiencia única para ti.
                </Card>
                <Card title="Asistentes de Voz" icon={<SmartphoneIcon className="h-8 w-8" />}>
                    Cuando le hablas a Siri o al Asistente de Google, una red neuronal procesa tu voz, entiende lo que dices y busca la respuesta correcta en una fracción de segundo.
                </Card>
                <Card title="Fotografía Inteligente" icon={<CameraIcon className="h-8 w-8" />}>
                    El 'modo retrato' que desenfoca el fondo de tus fotos, o la mejora automática de imágenes, son posibles gracias a redes que han aprendido a diferenciar personas de paisajes.
                </Card>
                <Card title="Traducción Instantánea" icon={<TranslateIcon className="h-8 w-8" />}>
                    Herramientas como Google Translate usan redes neuronales para traducir no solo palabras, sino el contexto y el significado de frases enteras entre cientos de idiomas.
                </Card>
                <Card title="Seguridad y Fraude" icon={<ShieldIcon className="h-8 w-8" />}>
                    Tu banco utiliza redes neuronales para analizar millones de transacciones y detectar patrones inusuales que podrían indicar un intento de fraude, protegiendo tu cuenta.
                </Card>
                <Card title="Conducción del Futuro" icon={<CarIcon className="h-8 w-8" />}>
                    Los coches autónomos usan redes neuronales para "ver" el mundo, identificando peatones, otros vehículos y señales de tráfico para tomar decisiones seguras.
                </Card>
            </div>

            <div className="mt-20 md:mt-32">
              <CartesianClassifier />
            </div>

            <div className="mt-20 text-center">
                <button 
                  onClick={onNavigate}
                  className="group inline-flex items-center gap-3 bg-orange-primary text-white font-bold text-lg px-8 py-4 rounded-lg shadow-lg shadow-orange-primary/30 hover:bg-orange-600 transition-all duration-300 transform hover:scale-105"
                >
                    <span className="transition-transform duration-300 group-hover:-translate-x-2">
                        <ArrowLeftIcon className="h-6 w-6" />
                    </span>
                    Volver
                </button>
            </div>
        </section>
    );
};

export default ImportancePage;