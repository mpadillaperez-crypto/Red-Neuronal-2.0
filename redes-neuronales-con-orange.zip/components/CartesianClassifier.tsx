import React, { useState, useEffect, useMemo } from 'react';
import { ChartBarIcon } from './Icons';

const initialPoints = Array.from({ length: 50 }, () => {
    const isClassA = Math.random() > 0.5;
    const padding = 10;
    const range = 80;
    let x, y;

    if (isClassA) {
        // Top-left cluster
        x = padding + Math.random() * (range / 2);
        y = padding + Math.random() * (range / 2);
    } else {
        // Bottom-right cluster
        x = (padding + range / 2) + Math.random() * (range / 2);
        y = (padding + range / 2) + Math.random() * (range / 2);
    }
    return { x, y, class: isClassA ? 0 : 1 };
});


const CartesianClassifier: React.FC = () => {
    const [points] = useState(initialPoints);
    const [w1, setW1] = useState(0.5);
    const [w2, setW2] = useState(0.5);
    const [bias, setBias] = useState(-50);

    const { accuracy, classifiedPoints } = useMemo(() => {
        let correctCount = 0;
        const classified = points.map(p => {
            const sum = p.x * w1 + p.y * w2 + bias;
            const predictedClass = sum > 0 ? 1 : 0;
            if (predictedClass === p.class) {
                correctCount++;
            }
            return { ...p, predictedClass };
        });
        return {
            accuracy: (correctCount / points.length) * 100,
            classifiedPoints: classified
        };
    }, [points, w1, w2, bias]);

    // Calculate line coordinates
    let x1 = 0, y1 = 0, x2 = 100, y2 = 100;
    if (Math.abs(w2) > 0.01) { // Avoid division by zero, treat as horizontal line
        y1 = (-w1 * x1 - bias) / w2;
        y2 = (-w1 * x2 - bias) / w2;
    } else { // Vertical line
        x1 = x2 = -bias / w1;
    }

    return (
        <section className="bg-slate-light p-8 rounded-2xl border border-slate-700">
            <div className="text-center mb-12">
                <div className="inline-block bg-orange-primary/10 p-4 rounded-full mb-4">
                    <ChartBarIcon className="h-10 w-10 text-orange-primary" />
                </div>
                <h2 className="text-3xl font-bold text-center mb-4">El Plano Cartesiano de la Decisión</h2>
                <p className="text-center text-gray-400 max-w-3xl mx-auto">
                    Una neurona aprende a trazar una "línea" para separar datos. ¡Intenta encontrar la mejor línea para clasificar los puntos naranjas y azules!
                </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8 items-center">
                <div className="lg:col-span-2 bg-slate-deep rounded-lg p-4 relative aspect-square">
                    <svg viewBox="0 0 100 100" className="w-full h-full">
                        {/* Grid lines */}
                        {Array.from({length: 9}).map((_, i) => (
                           <React.Fragment key={i}>
                             <line x1={(i+1)*10} y1="0" x2={(i+1)*10} y2="100" stroke="#1E293B" strokeWidth="0.2"/>
                             <line x1="0" y1={(i+1)*10} x2="100" y2={(i+1)*10} stroke="#1E293B" strokeWidth="0.2"/>
                           </React.Fragment>
                        ))}
                        
                        {/* Decision Boundary */}
                        <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#F97316" strokeWidth="1" strokeDasharray="2 1" />
                        
                        {/* Data Points */}
                        {classifiedPoints.map((p, i) => (
                            <circle key={i} cx={p.x} cy={p.y} r="1.5"
                                className={`transition-colors duration-300 ${p.class === 0 ? 'fill-sky-400' : 'fill-orange-400'}`}
                                opacity={p.predictedClass === p.class ? 1 : 0.4}
                            />
                        ))}
                    </svg>
                </div>

                <div className="space-y-6">
                    <div>
                        <div className="flex justify-between items-center mb-2">
                           <label htmlFor="w1" className="font-bold text-white">Peso X (Inclinación)</label>
                           <span className="text-orange-secondary font-mono">{w1.toFixed(2)}</span>
                        </div>
                        <input type="range" min="-1" max="1" step="0.05" value={w1} onChange={(e) => setW1(Number(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-primary" />
                    </div>
                     <div>
                        <div className="flex justify-between items-center mb-2">
                            <label htmlFor="w2" className="font-bold text-white">Peso Y (Inclinación)</label>
                            <span className="text-orange-secondary font-mono">{w2.toFixed(2)}</span>
                        </div>
                        <input type="range" min="-1" max="1" step="0.05" value={w2} onChange={(e) => setW2(Number(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-primary" />
                    </div>
                     <div>
                        <div className="flex justify-between items-center mb-2">
                            <label htmlFor="bias" className="font-bold text-white">Sesgo (Posición)</label>
                            <span className="text-orange-secondary font-mono">{bias.toFixed(0)}</span>
                        </div>
                        <input type="range" min="-100" max="0" step="1" value={bias} onChange={(e) => setBias(Number(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-primary" />
                    </div>
                    <div className="text-center bg-slate-deep p-4 rounded-lg">
                        <p className="text-gray-400 text-sm">Precisión de la Clasificación</p>
                        <p className="text-3xl font-bold transition-colors" style={{color: `hsl(${accuracy}, 100%, 60%)`}}>
                            {accuracy.toFixed(1)}%
                        </p>
                        <p className="text-xs text-gray-500 mt-2">Los puntos opacos están mal clasificados.</p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default CartesianClassifier;