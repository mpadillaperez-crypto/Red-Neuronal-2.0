
import React from 'react';

const Card: React.FC<{ title: string; children: React.ReactNode; icon: React.ReactNode }> = ({ title, children, icon }) => (
  <div className="bg-slate-light p-6 rounded-xl border border-slate-700 hover:border-orange-primary transition-all duration-300 transform hover:-translate-y-1">
    <div className="flex items-center gap-4 mb-3">
      <div className="bg-orange-primary/10 text-orange-primary p-2 rounded-lg">{icon}</div>
      <h3 className="text-xl font-bold text-white">{title}</h3>
    </div>
    <p className="text-gray-400">{children}</p>
  </div>
);

const Introduction: React.FC = () => {
  return (
    <section className="animate-fade-in" style={{ animationDelay: '200ms' }}>
      <h2 className="text-3xl font-bold text-center mb-12">¿Qué es una Red Neuronal? ¡Imagina un Cerebro Digital!</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <Card title="Inspirado en el Cerebro" icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.002 11a1.999 1.999 0 00-2-2h- circuitos ..."/></svg>}>
          Las redes neuronales son modelos informáticos inspirados en la estructura del cerebro humano. Están formadas por "neuronas" digitales interconectadas.
        </Card>
        <Card title="Aprenden de Ejemplos" icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v11.494m-9-5.747h18"/></svg>}>
          En lugar de programarlas con reglas, les mostramos muchos ejemplos. Ellas aprenden a reconocer patrones, como un niño aprende a diferenciar un perro de un gato.
        </Card>
        <Card title="Toman Decisiones" icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}>
          Una vez entrenadas, pueden hacer predicciones o tomar decisiones sobre datos nuevos que nunca han visto antes. ¡Desde recomendarte una película hasta diagnosticar enfermedades!
        </Card>
      </div>
    </section>
  );
};

export default Introduction;
