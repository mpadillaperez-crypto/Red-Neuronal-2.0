
import React from 'react';
import Header from './Header';
import Introduction from './Introduction';
import NeuronAnalogy from './NeuronAnalogy';
import NetworkExample from './NetworkExample';
import OrangeDataMinerSection from './OrangeDataMinerSection';
import { ArrowRightIcon } from './Icons';

interface MainPageProps {
  onNavigate: () => void;
}

const MainPage: React.FC<MainPageProps> = ({ onNavigate }) => {
  return (
    <>
      <Header />
      <div className="space-y-20 md:space-y-32">
        <Introduction />
        <NeuronAnalogy />
        <NetworkExample />
        <OrangeDataMinerSection />
      </div>
      <div className="mt-20 text-center">
        <button 
          onClick={onNavigate}
          className="group inline-flex items-center gap-3 bg-orange-primary text-white font-bold text-lg px-8 py-4 rounded-lg shadow-lg shadow-orange-primary/30 hover:bg-orange-600 transition-all duration-300 transform hover:scale-105"
        >
          Siguiente
          <span className="transition-transform duration-300 group-hover:translate-x-2">
            <ArrowRightIcon className="h-6 w-6" />
          </span>
        </button>
      </div>
    </>
  );
};

export default MainPage;
