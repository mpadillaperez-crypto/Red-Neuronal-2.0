
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="text-center py-8 mt-16 border-t border-slate-800">
      <p className="text-gray-500">
        Creado con fines educativos para desmitificar las Redes Neuronales.
      </p>
    </footer>
  );
};

export default Footer;
