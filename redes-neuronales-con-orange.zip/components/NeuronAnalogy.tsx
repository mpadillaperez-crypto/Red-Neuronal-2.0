
import React, { useState, useEffect } from 'react';
import { LightBulbIcon } from './Icons';

const NeuronAnalogy: React.FC = () => {
  const [isCloudy, setIsCloudy] = useState(true);
  const [forecastSaysRain, setForecastSaysRain] = useState(true);
  const [weightCloudy, setWeightCloudy] = useState(3);
  const [weightForecast, setWeightForecast] = useState(7);
  const [threshold] = useState(5);
  const [activation, setActivation] = useState(0);

  useEffect(() => {
    const cloudyValue = isCloudy ? 1 : 0;
    const forecastValue = forecastSaysRain ? 1 : 0;
    const total = (cloudyValue * weightCloudy) + (forecastValue * weightForecast);
    setActivation(total);
  }, [isCloudy, forecastSaysRain, weightCloudy, weightForecast]);

  const decision = activation >= threshold;

  return (
    <section className="animate-fade-in" style={{ animationDelay: '400ms' }}>
      <h2 className="text-3xl font-bold text-center mb-4">La Pieza Clave: La Neurona Artificial</h2>
      <p className="text-center text-gray-400 max-w-2xl mx-auto mb-12">
        Imagina que una neurona es un pequeño "tomador de decisiones". Usemos un ejemplo: ¿Deberías llevar paraguas?
      </p>

      <div className="grid md:grid-cols-2 gap-8 items-center bg-slate-light p-8 rounded-2xl border border-slate-700">
        {/* Controles Interactivos */}
        <div className="space-y-6">
          <div>
            <h3 className="text-xl font-bold mb-4">1. Entradas (Inputs)</h3>
            <div className="flex items-center justify-between bg-slate-deep p-4 rounded-lg">
              <label htmlFor="isCloudy">¿Está nublado?</label>
              <button
                onClick={() => setIsCloudy(!isCloudy)}
                className={`px-4 py-2 rounded-md font-semibold transition-colors ${isCloudy ? 'bg-orange-primary text-white' : 'bg-slate-700 text-gray-300'}`}
              >
                {isCloudy ? 'Sí' : 'No'}
              </button>
            </div>
             <div className="flex items-center justify-between bg-slate-deep p-4 rounded-lg mt-2">
              <label htmlFor="forecastSaysRain">¿El pronóstico dice lluvia?</label>
              <button
                onClick={() => setForecastSaysRain(!forecastSaysRain)}
                className={`px-4 py-2 rounded-md font-semibold transition-colors ${forecastSaysRain ? 'bg-orange-primary text-white' : 'bg-slate-700 text-gray-300'}`}
              >
                {forecastSaysRain ? 'Sí' : 'No'}
              </button>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">2. Pesos (Importancia)</h3>
            <div className="bg-slate-deep p-4 rounded-lg">
              <label htmlFor="weightCloudy" className="block mb-2">Importancia de "nublado": <span className="text-orange-secondary font-bold">{weightCloudy}</span></label>
              <input type="range" min="0" max="10" value={weightCloudy} onChange={(e) => setWeightCloudy(Number(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-primary" />
            </div>
            <div className="bg-slate-deep p-4 rounded-lg mt-2">
              <label htmlFor="weightForecast" className="block mb-2">Importancia del pronóstico: <span className="text-orange-secondary font-bold">{weightForecast}</span></label>
              <input type="range" min="0" max="10" value={weightForecast} onChange={(e) => setWeightForecast(Number(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-primary" />
            </div>
          </div>
        </div>

        {/* Visualización y Decisión */}
        <div className="flex flex-col items-center justify-center bg-slate-deep p-8 rounded-xl h-full">
            <h3 className="text-xl font-bold mb-4">3. La Decisión</h3>
            <div className="w-48 h-48 rounded-full flex items-center justify-center border-4 transition-colors duration-500"
                 style={{ borderColor: decision ? '#F97316' : '#475569', boxShadow: decision ? `0 0 25px #F97316` : 'none' }}>
              <LightBulbIcon className={`h-24 w-24 transition-colors duration-500 ${decision ? 'text-orange-primary' : 'text-slate-600'}`} />
            </div>
            <p className="text-center mt-6 text-lg">
              Suma ponderada: <span className="font-bold text-white">{activation.toFixed(0)}</span> / Umbral: <span className="font-bold text-white">{threshold}</span>
            </p>
            <div className={`mt-4 text-2xl font-bold p-3 rounded-lg transition-all duration-300 ${decision ? 'bg-orange-primary text-white' : 'bg-slate-700 text-gray-400'}`}>
              {decision ? '¡Lleva paraguas!' : 'No necesitas paraguas'}
            </div>
             <p className="text-xs text-gray-500 mt-4 text-center">La neurona se "activa" si la suma de las entradas multiplicadas por su importancia supera un umbral.</p>
        </div>
      </div>
    </section>
  );
};

export default NeuronAnalogy;
